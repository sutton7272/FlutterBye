import{j as s,al as t}from"./index-CeACcdR0.js";function r({className:a,...e}){return s.jsx("div",{className:t("animate-pulse rounded-md bg-slate-100 dark:bg-slate-800",a),...e})}export{r as S};
